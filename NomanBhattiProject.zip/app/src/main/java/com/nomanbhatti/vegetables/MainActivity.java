package com.nomanbhatti.vegetables;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.content.Intent;

public class MainActivity extends Activity {
 String[] names={"مٹر","پالک","مولی","گوبھی","پھلیاں","کدو","بینگن","شلجم","گاجر","آلو","پیاز","ٹماٹر","دھنیا","ہری مرچ","تھوم","ادرک"};
 int[] prices={440,40,100,140,70,50,50,50,70,160,230,240,240,240,450,450};
 EditText[] qtys; EditText customerName,phone,address; TextView totalView; LinearLayout root; int green=Color.rgb(28,125,62);
 public void onCreate(Bundle b){super.onCreate(b);
  ScrollView sc=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,32); root.setBackgroundColor(Color.rgb(247,250,246)); sc.addView(root); setContentView(sc);
  TextView title=new TextView(this); title.setText("نعمان بھٹی فریش سبزیاں"); title.setTextSize(27); title.setTypeface(null,Typeface.BOLD); title.setTextColor(green); title.setGravity(Gravity.CENTER); root.addView(title,lp());
  TextView sub=new TextView(this); sub.setText("آن لائن سبزی آرڈر"); sub.setTextSize(18); sub.setGravity(Gravity.CENTER); sub.setPadding(0,4,0,18); root.addView(sub,lp());
  label("گاہک کا نام"); customerName=input("اپنا نام لکھیں"); label("موبائل نمبر"); phone=input("03xxxxxxxxx"); label("مکمل پتہ"); address=input("گھر کا پتہ لکھیں");
  label("سبزی منتخب کریں (کلوگرام)"); qtys=new EditText[names.length];
  for(int i=0;i<names.length;i++){LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(8,8,8,8); row.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams rlp=lp(); rlp.bottomMargin=6; root.addView(row,rlp);
   TextView nm=new TextView(this); nm.setText(names[i]+" — Rs. "+prices[i]+"/kg"); nm.setTextSize(16); nm.setTextColor(Color.DKGRAY); row.addView(nm,new LinearLayout.LayoutParams(0,-2,1));
   EditText q=new EditText(this); q.setHint("0"); q.setText("0"); q.setInputType(8194); q.setSingleLine(true); q.setGravity(Gravity.CENTER); q.setTextSize(16); row.addView(q,new LinearLayout.LayoutParams(82,48)); qtys[i]=q;
   q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){updateTotal();} public void afterTextChanged(android.text.Editable e){}});
  }
  totalView=new TextView(this); totalView.setTextSize(22); totalView.setTypeface(null,Typeface.BOLD); totalView.setTextColor(green); totalView.setPadding(0,18,0,18); root.addView(totalView,lp()); Button order=new Button(this); order.setText("WhatsApp پر آرڈر بھیجیں"); order.setTextColor(Color.WHITE); order.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); root.addView(order,lp()); order.setOnClickListener(v->sendOrder()); updateTotal();
 }
 LinearLayout.LayoutParams lp(){return new LinearLayout.LayoutParams(-1,-2);}
 void label(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setTypeface(null,Typeface.BOLD);t.setPadding(0,10,0,4);root.addView(t,lp());}
 EditText input(String s){EditText e=new EditText(this);e.setHint(s);e.setTextSize(16);e.setPadding(12,8,12,8);e.setBackgroundColor(Color.WHITE);root.addView(e,lp());return e;}
 double qty(int i){try{return Double.parseDouble(qtys[i].getText().toString().trim());}catch(Exception e){return 0;}}
 int total(){double t=0;for(int i=0;i<names.length;i++)t+=qty(i)*prices[i];return (int)Math.round(t);}
 void updateTotal(){if(totalView!=null)totalView.setText("کل رقم: Rs. "+total());}
 void sendOrder(){String n=customerName.getText().toString().trim(),p=phone.getText().toString().trim(),a=address.getText().toString().trim();
  if(n.isEmpty()||p.isEmpty()||a.isEmpty()){Toast.makeText(this,"براہ کرم نام، موبائل نمبر اور پتہ لکھیں",Toast.LENGTH_LONG).show();return;}
  StringBuilder m=new StringBuilder("نیا سبزی آرڈر - نعمان بھٹی\nنام: "+n+"\nموبائل: "+p+"\nپتہ: "+a+"\n\n");boolean any=false;
  for(int i=0;i<names.length;i++){double q=qty(i);if(q>0){any=true;m.append(names[i]).append(": ").append(q).append(" کلو × ").append(prices[i]).append(" = ").append((int)(q*prices[i])).append(" روپے\n");}}
  if(!any){Toast.makeText(this,"کم از کم ایک سبزی کی مقدار لکھیں",Toast.LENGTH_LONG).show();return;} m.append("\nکل رقم: Rs. ").append(total());
  Intent in=new Intent(Intent.ACTION_SEND);in.setType("text/plain");in.putExtra(Intent.EXTRA_TEXT,m.toString());in.setPackage("com.whatsapp");
  try{startActivity(in);}catch(Exception ex){Intent chooser=new Intent(Intent.ACTION_SEND);chooser.setType("text/plain");chooser.putExtra(Intent.EXTRA_TEXT,m.toString());startActivity(Intent.createChooser(chooser,"آرڈر بھیجنے کے لیے ایپ منتخب کریں"));}
 }
}
