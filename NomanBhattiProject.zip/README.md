# Noman Bhatti Fresh Vegetables
Simple Android vegetable ordering app with Urdu labels, sample prices, quantity selection, total calculation, and WhatsApp order sharing.
