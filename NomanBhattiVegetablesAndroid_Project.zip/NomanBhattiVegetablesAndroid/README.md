# Noman Bhatti Fresh Vegetables — Android project

This is the Android Studio source project for the vegetable-ordering app.

## Included
- Urdu-first interface
- Latest vegetable prices supplied by the shop owner
- Quantity in kg and automatic total
- Customer name, phone and address
- Shares the order text using Android's share sheet, so WhatsApp can be selected

## Build APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by Android Studio.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For a shareable release APK, use **Build > Generate Signed Bundle / APK** and create a signing key.

The project source has not been compiled or tested into an APK in this environment. You must build it in Android Studio before installing it. Prices are sample defaults based on the latest rates supplied; update them in `MainActivity.kt` whenever rates change.
