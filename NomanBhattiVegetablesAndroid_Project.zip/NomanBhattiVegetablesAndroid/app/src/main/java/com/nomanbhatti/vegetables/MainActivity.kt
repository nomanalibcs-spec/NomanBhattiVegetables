package com.nomanbhatti.vegetables

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val vegetables = listOf(
        Veg("مٹر", 440), Veg("پالک", 40), Veg("مولی", 100), Veg("گوبھی", 140),
        Veg("پھلیاں", 70), Veg("کدو", 50), Veg("بینگن", 50), Veg("شلجم", 50),
        Veg("گاجر", 70), Veg("آلو", 160), Veg("پیاز", 230), Veg("ٹماٹر", 240),
        Veg("دھنیا", 240), Veg("ہری مرچ", 240), Veg("تھوم", 450), Veg("ادرک", 450)
    )
    private val qtyInputs = mutableListOf<EditText>()
    private lateinit var totalText: TextView
    private lateinit var nameInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var addressInput: EditText

    data class Veg(val name: String, val price: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(23, 101, 44)
        window.navigationBarColor = Color.rgb(23, 101, 44)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 249, 244))
        }
        val header = TextView(this).apply {
            text = "نعمان بھٹی فریش سبزیاں\nNoman Bhatti Fresh Vegetables"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(16, 22, 16, 22)
            setBackgroundColor(Color.rgb(23, 101, 44))
        }
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 20)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(sectionTitle("سبزی منتخب کریں — ریٹ فی کلو"))
        vegetables.forEachIndexed { index, veg ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 8, 10, 8)
                setBackgroundColor(if (index % 2 == 0) Color.WHITE else Color.rgb(237, 244, 233))
            }
            val label = TextView(this).apply {
                text = "${veg.name}   —   Rs ${veg.price}/kg"
                textSize = 17f
                setTextColor(Color.rgb(35, 50, 35))
            }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val qty = EditText(this).apply {
                hint = "کلو"
                textSize = 16f
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                gravity = Gravity.CENTER
                setSingleLine(true)
                setTextColor(Color.BLACK)
                setBackgroundColor(Color.rgb(250, 250, 250))
                setPadding(8, 8, 8, 8)
                filters = arrayOf(android.text.InputFilter.LengthFilter(6))
                addTextChangedListener(SimpleTextWatcher { updateTotal() })
            }
            qty.layoutParams = LinearLayout.LayoutParams(dp(78), dp(46))
            row.addView(qty)
            qtyInputs.add(qty)
            content.addView(row)
            val divider = View(this).apply { setBackgroundColor(Color.rgb(220, 228, 216)) }
            content.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }

        totalText = TextView(this).apply {
            text = "کل رقم: Rs 0"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(23, 101, 44))
            setPadding(12, 18, 12, 18)
        }
        content.addView(totalText)
        content.addView(sectionTitle("گاہک کی معلومات"))

        nameInput = makeInput("گاہک کا نام")
        phoneInput = makeInput("موبائل نمبر", InputType.TYPE_CLASS_PHONE)
        addressInput = makeInput("مکمل پتہ")
        content.addView(nameInput)
        content.addView(phoneInput)
        content.addView(addressInput)

        val orderButton = Button(this).apply {
            text = "آرڈر واٹس ایپ پر بھیجیں"
            textSize = 17f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(23, 101, 44))
            setOnClickListener { shareOrder() }
        }
        content.addView(orderButton, LinearLayout.LayoutParams(-1, dp(54)))
        val note = TextView(this).apply {
            text = "نوٹ: آرڈر بھیجنے کے بعد واٹس ایپ میں دکان کا نمبر منتخب کریں۔"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(6, 12, 6, 8)
        }
        content.addView(note)
        setContentView(root)
    }

    private fun sectionTitle(s: String) = TextView(this).apply {
        text = s
        textSize = 18f
        setTextColor(Color.rgb(23, 101, 44))
        setPadding(4, 16, 4, 10)
    }

    private fun makeInput(hintText: String, type: Int = InputType.TYPE_CLASS_TEXT) =
        EditText(this).apply {
            hint = hintText
            inputType = type
            textSize = 16f
            setSingleLine(false)
            setPadding(12, 10, 12, 10)
            val lp = LinearLayout.LayoutParams(-1, dp(52))
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }

    private fun updateTotal() {
        var total = 0.0
        vegetables.forEachIndexed { i, veg ->
            val q = qtyInputs.getOrNull(i)?.text?.toString()?.toDoubleOrNull() ?: 0.0
            total += q * veg.price
        }
        totalText.text = "کل رقم: Rs ${"%.0f".format(Locale.US, total)}"
    }

    private fun shareOrder() {
        val name = nameInput.text.toString().trim()
        val phone = phoneInput.text.toString().trim()
        val address = addressInput.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, "براہ کرم نام، موبائل نمبر اور پتہ لکھیں۔", Toast.LENGTH_LONG).show()
            return
        }
        val selected = mutableListOf<String>()
        var total = 0.0
        vegetables.forEachIndexed { i, veg ->
            val qty = qtyInputs[i].text.toString().toDoubleOrNull() ?: 0.0
            if (qty > 0) {
                val lineTotal = qty * veg.price
                total += lineTotal
                selected.add("${veg.name}: ${qty} کلو × Rs ${veg.price} = Rs ${"%.0f".format(Locale.US, lineTotal)}")
            }
        }
        if (selected.isEmpty()) {
            Toast.makeText(this, "پہلے کم از کم ایک سبزی کی مقدار لکھیں۔", Toast.LENGTH_LONG).show()
            return
        }
        val message = buildString {
            append("Noman Bhatti Fresh Vegetables\nنیا آرڈر\n\n")
            append("نام: $name\nموبائل: $phone\nپتہ: $address\n\n")
            append(selected.joinToString("\n"))
            append("\n\nکل رقم: Rs ${"%.0f".format(Locale.US, total)}")
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
        }
        startActivity(Intent.createChooser(intent, "آرڈر کہاں بھیجنا ہے؟"))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private class SimpleTextWatcher(val changed: () -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
